Build Instructions (Athena with Makefile)
==================
$ mkdir build
$ cd build
$ cmake ..
$ make

The sample solution binaries are in sample_solution/

Submission
==========
We only provide official support for developing under the Athena cluster.
Your submission has to build and run over there to receive credit.

Please submit your entire source directory (excluding the build
directory) and compiled binary in inst/.
