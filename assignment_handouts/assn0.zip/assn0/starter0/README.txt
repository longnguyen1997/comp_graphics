Contents of Starter

Cmake
 - CMakeLists.txt: contains the build information for the project.
 - build: the directory where your project will be built.

Source and Data
 - src:   starter code. Add your source code here.
 - data:  test files for your solution.
 - solution: example solution (binary).

Dependencies
 - vecmath: source code for vecmath library.
 - glew:  source code for GLEW library.
 - glfw:  source code for GLFW library.
