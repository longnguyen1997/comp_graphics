6.837 - Problem Set 2
Hierarchical Modeling

1) Compiling and running?

cd <starter2 dir>; mkdir build; cd build; cmake -j ..; make -j; ./a2 ../data/Model1

2) Collaboration?

Absolutely none.

3) References?

StackOverflow. https://stackoverflow.com/a/1966605 is the best resource possible
for finding out exactly how to cross-product the triangle face edges for normal
generation in the proper direction.

4) Known problems?

Not that I know of. I can't tell much of a difference in terms of rendering from
my solution compared to the sample solution. I hope it counts.

5) Extra credit?

None.

6) Comments?

Please encourage students to look up theoretical knowledge required to complete
these labs. I always assume that the PDF has all I need, but a lot of details
aren't clear until I look them up (like the cross product derivation for the
face normals I mentioned above).

